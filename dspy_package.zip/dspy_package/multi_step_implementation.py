'''
Workflow:

    Intent Classification

        Decide if the question is general, answerable, or irrelevant.

    Clarification

        If it's too vague or missing info → ask for more details.

    SQL Generation & Execution

        If answerable → generate SQL → fetch from DB → generate natural language answer.

    Fallback

        If irrelevant → respond: “I can’t answer that.”
'''



from dspy import Module, PromptModule, ChainOfThought, Prediction

class RequestClarification(Signature):
    question: str
    clarification: str

class ClassifyQuestion(Signature):
    question: str
    intent: str  # one of: ["clarify", "answer", "irrelevant"]

class NLToSQL(Signature):
    question: str
    sql: str

class SQLToAnswer(Signature):
    sql: str
    result: str
    answer: str


class SmartQueryAgent(Module):
    def __init__(self):
        super().__init__()
        self.classifier = PromptModule(ClassifyQuestion)
        self.clarifier = ChainOfThought(RequestClarification)
        self.sql_generator = ChainOfThought(NLToSQL)
        self.answer_generator = ChainOfThought(SQLToAnswer)

    def forward(self, question: str, db_executor) -> Prediction:
        intent_result = self.classifier(question=question)
        intent = intent_result.intent.lower()

        if intent == "irrelevant":
            return Prediction(answer="I can't answer that question.")

        elif intent == "clarify":
            follow_up = self.clarifier(question=question)
            return Prediction(answer=f" Could you clarify: {follow_up.clarification}?")

        elif intent == "answer":
            sql = self.sql_generator(question=question).sql
            result = db_executor(sql)  # function to fetch from DB
            answer = self.answer_generator(sql=sql, result=result).answer
            return Prediction(answer=answer)

        return Prediction(answer="I'm not sure how to handle this.")
