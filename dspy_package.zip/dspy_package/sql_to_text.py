from dspy import Signature

class QuestionToSQL(Signature):
    """Turn a question into a SQL query."""
    question: str
    sql: str



class SQLToAnswer(Signature):
    """Turn a SQL query and result into a human-readable answer."""
    sql: str
    result: str  # stringified SQL result
    answer: str


from dspy import ChainOfThought, Predict, OpenAI
import dspy

# Use GPT-4 or any model
dspy.settings.configure(lm=OpenAI(model='gpt-4'))

# Define the modules
generate_sql = ChainOfThought(QuestionToSQL)
generate_answer = ChainOfThought(SQLToAnswer)

# Step 1: NL to SQL
question = "How many users signed up in the last 30 days?"
sql_response = generate_sql(question=question)

# Step 2: Execute the SQL (mock or real)
# Replace this with actual DB call
mock_result = "42"  # Or use your DB to run sql_response.sql

# Step 3: SQL to natural language answer
answer_response = generate_answer(sql=sql_response.sql, result=mock_result)

# Final output
print("🧠 Final Answer:", answer_response.answer)
