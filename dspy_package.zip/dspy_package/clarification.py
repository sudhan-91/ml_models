import dspy
from dspy import Signature, Example, ChainOfThought, Optimize, OpenAI

# Step 1: Configure LLM (GPT-4 or GPT-3.5)
dspy.settings.configure(lm=OpenAI(model='gpt-4'))  # Set OPENAI_API_KEY as env variable

# Step 2: Define the Signature
class RequestClarification(Signature):
    """Generate a clarifying question when the user query is vague."""
    question: str
    clarification: str

# Step 3: Create the reasoning module
clarifier = ChainOfThought(RequestClarification)

# Step 4: Provide training examples
examples = [
    Example(
        question="What about users?",
        clarification="Are you asking about user growth, retention, or demographics?"
    ),
    Example(
        question="How is revenue?",
        clarification="Do you want revenue by product, region, or time period?"
    ),
    Example(
        question="Show me sales.",
        clarification="Could you specify which region or timeframe for sales?"
    ),
    Example(
        question="Tell me the stats.",
        clarification="Which stats are you referring to — revenue, users, or product usage?"
    )
]

# Step 5: Optimize the module using examples
optimized_clarifier = Optimize(clarifier, trainset=examples).run()

# Step 6: Use the optimized module on a new vague query
test_query = "Can you tell me about the customers?"
response = optimized_clarifier(question=test_query)

print("🧠 Clarification Needed:")
print(response.clarification)
