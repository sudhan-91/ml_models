from langchain_experimental.sql import SQLDatabaseChain

chain = SQLDatabaseChain.from_llm(llm, db, verbose=True)
chain.run("What is the total revenue last month?")
