from langchain_experimental.sql import SQLDatabaseChain

chain = SQLDatabaseChain.from_llm(
    llm=llm,
    db=db,
    verbose=True,
    return_intermediate_steps=True,
    use_query_checker=True,
    top_k=5  # returns top 5 similar tables if unsure
)
