from langchain.prompts import FewShotPromptTemplate, PromptTemplate
from langchain_experimental.sql import SQLDatabaseChain

# Example question → SQL pair
examples = [
    {
        "question": "How many orders were made in January 2024?",
        "sql": "SELECT COUNT(*) FROM orders WHERE date >= '2024-01-01' AND date < '2024-02-01';"
    },
    {
        "question": "Total revenue last month?",
        "sql": "SELECT SUM(revenue) FROM sales WHERE date >= '2024-03-01' AND date < '2024-04-01';"
    },
]

example_prompt = PromptTemplate(
    input_variables=["question", "sql"],
    template="Question: {question}\nSQL Query: {sql}"
)

few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    prefix="You are a SQL expert. Convert questions into valid SQL queries based on the schema.",
    suffix="Question: {input}\nSQL Query:",
    input_variables=["input"]
)

# Create chain with custom prompt
chain = SQLDatabaseChain.from_llm(llm, db, prompt=few_shot_prompt, verbose=True)
