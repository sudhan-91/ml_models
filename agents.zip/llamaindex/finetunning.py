training_data = [
    {
        "question": "Get the top 5 customers by revenue",
        "sql": "SELECT TOP 5 name FROM customers ORDER BY revenue DESC"
    },
    {
        "question": "Show total sales by region",
        "sql": "SELECT region, SUM(sales) FROM sales GROUP BY region"
    },
    # Add more...
]

from llama_index.schema import Document

docs = [Document(text=f"Q: {item['question']}\nSQL: {item['sql']}") for item in training_data]

from llama_index import VectorStoreIndex

index = VectorStoreIndex.from_documents(docs)
retriever = index.as_retriever(similarity_top_k=2)

from llama_index.llms import OpenAI
from llama_index.prompts import PromptTemplate
from llama_index.llm_predictor import LLMPredictor
from llama_index.query_engine import RetrieverQueryEngine

llm = OpenAI(model="gpt-4", temperature=0)

prompt_template = PromptTemplate(
    "You are a SQL generator. Given examples and a question, return SQL Server syntax.\n\n"
    "Examples:\n{context_str}\n\n"
    "Now answer this:\nQ: {query_str}\nSQL:"
)

query_engine = RetrieverQueryEngine.from_args(
    retriever=retriever,
    llm=llm,
    text_qa_template=prompt_template
)


response = query_engine.query("Show me total sales by product")
print(response)
