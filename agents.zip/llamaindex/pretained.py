from sqlalchemy import create_engine
from llama_index import SQLDatabase

# Replace with your actual credentials
server = 'YOUR_SERVER'
database = 'YOUR_DATABASE'
username = 'YOUR_USERNAME'
password = 'YOUR_PASSWORD'

connection_string = (
    f"mssql+pyodbc://{username}:{password}@{server}/{database}"
    "?driver=ODBC+Driver+17+for+SQL+Server"
)

engine = create_engine(connection_string)
sql_database = SQLDatabase(engine)


from llama_index.llms import OpenAI
from llama_index import SQLDatabaseToolkit, ServiceContext
from llama_index.agent import SQLAgent
from llama_index.llm_predictor import LLMPredictor

# Use OpenAI or other LLM
llm = OpenAI(temperature=0)

service_context = ServiceContext.from_defaults(
    llm_predictor=LLMPredictor(llm=llm)
)

toolkit = SQLDatabaseToolkit(sql_database=sql_database, llm=llm)
agent = SQLAgent.from_toolkit(toolkit, service_context=service_context)

response = agent.query("List the top 10 customers by total purchase amount.")
print(response)
