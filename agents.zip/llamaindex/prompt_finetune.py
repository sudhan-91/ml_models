# Example structure for a training log
training_data = []

def log_interaction(nl_question, generated_sql, user_feedback, corrected_sql=None):
    training_data.append({
        "question": nl_question,
        "generated_sql": generated_sql,
        "feedback": user_feedback,
        "corrected_sql": corrected_sql,
    })

import json

def save_training_data(filepath="sql_training_data.json"):
    with open(filepath, "w") as f:
        json.dump(training_data, f, indent=2)


{
  "question": "Get the top 5 employees by salary.",
  "generated_sql": "SELECT name FROM employees ORDER BY salary LIMIT 5",
  "feedback": "incorrect",
  "corrected_sql": "SELECT TOP 5 name FROM employees ORDER BY salary DESC"
}


from llama_index.llms import OpenAI
from llama_index.prompts import PromptTemplate
from llama_index.llm_predictor import LLMPredictor

# Load few-shot examples from training data
def load_few_shot_examples(filepath="sql_training_data.json", num_examples=3):
    with open(filepath, "r") as f:
        data = json.load(f)
    return [item for item in data if item["feedback"] == "incorrect"][:num_examples]

few_shots = load_few_shot_examples()

# Construct custom prompt template
examples_text = "\n\n".join([
    f"Q: {item['question']}\nSQL: {item['corrected_sql']}"
    for item in few_shots
])

custom_prompt = PromptTemplate(
    template=f"""
You are a SQL expert. Convert natural language questions to SQL queries.

Use SQL Server syntax (e.g., TOP instead of LIMIT).

Here are some examples:

{examples_text}

Now answer this:

Q: {{input}}
SQL:"""
)

# Use the custom prompt in your LLM
llm = OpenAI(model="gpt-4", temperature=0)
llm_predictor = LLMPredictor(llm=llm, prompt=custom_prompt)
