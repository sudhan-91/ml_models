import dspy

class NL2SQL(dspy.Signature):
    """Converts a natural language question to SQL."""
    question = dspy.InputField()
    schema = dspy.InputField(desc="The SQL table schema and metadata")
    sql = dspy.OutputField(desc="The SQL query in SQL Server syntax")


from dspy import OpenAI, Module

# Define LLM backend
dspy.settings.configure(OpenAI(model='gpt-4', api_key="your-key"))

# Module using your signature
class SQLGenerator(Module):
    def __init__(self):
        super().__init__()
        self.predictor = dspy.Predict(NL2SQL)

    def forward(self, question, schema):
        return self.predictor(question=question, schema=schema)

schema = """
Table: customers
Columns: id, name, revenue, region
"""

sql_gen = SQLGenerator()
output = sql_gen(question="Get the top 5 customers by revenue", schema=schema)

print(output.sql)
