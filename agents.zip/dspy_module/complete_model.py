import dspy
from dspy.teleprompt import BootstrapFewShot

# 1. Choose your LLM backend (OpenAI, Mistral, SQLCoder)
dspy.settings.configure(lm=dspy.OpenAI(model='gpt-4'))  # or dspy.HFLLM(model='defog/sqlcoder')

# 2. Define schema-aware module
class SQLAgent(dspy.Signature):
    """Convert natural language questions to SQL queries."""
    question = dspy.InputField(desc="User question")
    schema = dspy.InputField(desc="Schema of the SQL tables")
    sql = dspy.OutputField(desc="SQL query")

class NL2SQLModule(dspy.Module):
    def __init__(self):
        super().__init__()
        self.generator = dspy.Predict(SQLAgent)

    def forward(self, question, schema):
        return self.generator(question=question, schema=schema)

# 3. Train / bootstrap
train_data = [
    {"question": "Show total revenue by region", "sql": "SELECT region, SUM(revenue) FROM customers GROUP BY region"},
    {"question": "Top 5 customers", "sql": "SELECT name FROM customers ORDER BY revenue DESC LIMIT 5"},
]

trainset = [dspy.Example(**x).with_inputs("question", "schema") for x in train_data]
compiled = BootstrapFewShot(NL2SQLModule(), trainset=trainset).compile()

# 4. Query with schema
schema = "Table: customers (id, name, revenue, region)"
output = compiled(question="Which customer has the highest revenue?", schema=schema)
print(output.sql)
