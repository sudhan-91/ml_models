examples = [
    {
        "question": "Get the top 5 customers by revenue",
        "schema": schema,
        "sql": "SELECT TOP 5 name FROM customers ORDER BY revenue DESC"
    },
    {
        "question": "Show revenue by region",
        "schema": schema,
        "sql": "SELECT region, SUM(revenue) FROM customers GROUP BY region"
    },
]

from dspy.teleprompt import BootstrapFewShot

trainset = [dspy.Example(**e) for e in examples]

tuner = BootstrapFewShot(metric=dspy.exact_match)
sql_gen_tuned = SQLGenerator()

tuner.tune(sql_gen_tuned, trainset=trainset)
