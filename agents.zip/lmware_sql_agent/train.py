from llmware import SQLAgent

# Example training data: Question → SQL
training_data = [
    {"question": "Get the top 5 customers by revenue", "sql": "SELECT TOP 5 name FROM customers ORDER BY revenue DESC"},
    {"question": "Get the total revenue by region", "sql": "SELECT region, SUM(revenue) FROM customers GROUP BY region"}
]

# Initialize the SQL Agent
sql_agent = SQLAgent(model="gpt-4", schema=schema)

# Train the agent using the example questions and SQL queries
sql_agent.train(training_data)

# Query after training
question = "Get the total revenue by region"
generated_sql = sql_agent.ask(question)
print(f"Generated SQL after training: {generated_sql}")
