from llmware import PromptTemplate

# Custom template to pass schema along with the query
template = PromptTemplate(
    input_variables=["question", "schema"],
    template="""
    The following is the schema of the database:
    {schema}

    You need to generate a SQL query to answer the question: 
    {question}
    """
)

# Initialize the SQLAgent with the custom prompt template
sql_agent = SQLAgent(model="gpt-4", schema=schema, prompt_template=template)

# Ask the agent a question
question = "What is the total revenue by customer region?"
generated_sql = sql_agent.ask(question)
print(f"Generated SQL with custom prompt: {generated_sql}")
