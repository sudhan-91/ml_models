from llmware import SQLAgent, PromptTemplate

# Define your schema (simple example here)
schema = """
Table: customers
Columns: id (INT), name (VARCHAR), revenue (DECIMAL), region (VARCHAR)

Table: orders
Columns: order_id (INT), customer_id (INT), amount (DECIMAL), order_date (DATE)
"""

# Initialize SQLAgent with a model and schema
sql_agent = SQLAgent(model="gpt-4", schema=schema)

# Query: "Get the total revenue by region"
question = "Get the total revenue by region"

# Get the generated SQL query
generated_sql = sql_agent.ask(question)
print(f"Generated SQL: {generated_sql}")
