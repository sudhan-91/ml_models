import pyodbc

# Set up the connection to your SQL Server
connection_string = "Driver={ODBC Driver 17 for SQL Server};Server=your-server;Database=your-db;UID=user;PWD=password"
connection = pyodbc.connect(connection_string)
cursor = connection.cursor()

# Generate SQL query from agent
sql_query = sql_agent.ask("Get the total revenue by region")

# Execute the generated SQL
cursor.execute(sql_query)
rows = cursor.fetchall()

# Print the results
for row in rows:
    print(row)
