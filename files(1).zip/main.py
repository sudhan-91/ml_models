"""
QUAI – Multiproduct Backend API
Entry point – creates the FastAPI app and wires up all routers.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routers import chat

app = FastAPI(
    title="QUAI Multiproduct API",
    description="Backend API for QUAI multiproduct data processing and export.",
    version="1.0.0",
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(chat.router, prefix="/api", tags=["Chat & Data"])
