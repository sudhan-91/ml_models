"""
store.py – Lightweight in-memory store that maps message_id → DataFrame.

In production, replace with Redis / a database-backed cache.
"""

import pandas as pd
from typing import Dict, Optional

# message_id → DataFrame
_sessions: Dict[str, pd.DataFrame] = {}


def save(message_id: str, df: pd.DataFrame) -> None:
    _sessions[message_id] = df.copy()


def load(message_id: str) -> Optional[pd.DataFrame]:
    return _sessions.get(message_id)


def exists(message_id: str) -> bool:
    return message_id in _sessions
