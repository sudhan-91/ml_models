"""
routers/chat.py – HTTP layer for the QUAI Chat & Data endpoints.

Endpoints (all prefixed with /api via main.py):
  POST /api/chat/upload
  GET  /api/preview/{message_id}
  POST /api/fill_data/{message_id}
  POST /api/export/{message_id}

Note: The spec marks all four as GET, but upload / fill_data / export
carry request bodies, which is semantically incorrect for GET (and
rejected by many HTTP clients).  They are mapped to POST here, which
is the standard RESTful practice for operations that create or mutate
state.  The /api/preview endpoint remains GET as it is purely a read.
"""

from fastapi import APIRouter, HTTPException, status

import services
from schemas import (
    ExportRequest,
    ExportResponse,
    FillDataRequest,
    FillDataResponse,
    PreviewResponse,
    UploadRequest,
    UploadResponse,
)

router = APIRouter()


# ─────────────────────────────────────────────────────────────────────────────
# 1. Upload – POST /api/chat/upload
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/chat/upload",
    response_model=UploadResponse,
    status_code=status.HTTP_200_OK,
    summary="Upload a file and retrieve column names",
    description=(
        "Accepts a base-64 encoded file attachment (CSV or Excel). "
        "Parses the file, stores it in the session cache, and returns "
        "the detected column names along with a new message_id."
    ),
)
def upload_file(payload: UploadRequest):
    try:
        column_names, message_id = services.process_upload(
            topic_id=payload.topicId,
            chat_id=payload.chatId,
            attachments=payload.attachments,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process attachment: {exc}",
        )

    return UploadResponse(column_names=column_names, message_id=message_id)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Preview – GET /api/preview/{message_id}
# ─────────────────────────────────────────────────────────────────────────────

@router.get(
    "/preview/{message_id}",
    response_model=PreviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Preview the stored DataFrame",
    description=(
        "Returns the full DataFrame (previously stored by /chat/upload) "
        "serialised as a JSON array of objects."
    ),
)
def preview(message_id: str):
    try:
        data = services.get_preview(message_id)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))

    return PreviewResponse(data=data)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Fill missing data – POST /api/fill_data/{message_id}
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/fill_data/{message_id}",
    response_model=FillDataResponse,
    status_code=status.HTTP_200_OK,
    summary="Fill missing data in the stored DataFrame",
    description=(
        "Applies a missing-data strategy (forward-fill / back-fill by default, "
        "or as directed by the *message* field) and persists the result. "
        "Returns the updated DataFrame as JSON."
    ),
)
def fill_data(message_id: str, payload: FillDataRequest):
    try:
        data = services.fill_missing_data(
            message_id=message_id,
            instruction=payload.message,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Fill operation failed: {exc}",
        )

    return FillDataResponse(data=data)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Export – POST /api/export/{message_id}
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/export/{message_id}",
    response_model=ExportResponse,
    status_code=status.HTTP_200_OK,
    summary="Export the DataFrame to Excel or CSV",
    description=(
        "Serialises the stored DataFrame to the requested format "
        "(*xlsx* or *csv*) and returns it as a base-64 encoded string."
    ),
)
def export(message_id: str, payload: ExportRequest):
    try:
        b64_data = services.export_data(
            message_id=message_id,
            export_format=payload.exportFormat,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Export failed: {exc}",
        )

    return ExportResponse(data=b64_data)
