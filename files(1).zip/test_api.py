"""
tests/test_api.py – Integration tests for the QUAI API using FastAPI's TestClient.

Run with:  pytest tests/
"""

import base64
import io
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pandas as pd
import pytest
from fastapi.testclient import TestClient

from main import app

client = TestClient(app)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_csv_b64(rows: list[dict]) -> str:
    df = pd.DataFrame(rows)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return base64.b64encode(buf.getvalue().encode()).decode()


SAMPLE_ROWS = [
    {"DIVISION_SHORT_DESCR": "Alpha", "SUB_DIVISION_SHORT_DESCR": "A1", "BUSINESS_SEGMENT": "Retail"},
    {"DIVISION_SHORT_DESCR": None,    "SUB_DIVISION_SHORT_DESCR": "B2", "BUSINESS_SEGMENT": None},
    {"DIVISION_SHORT_DESCR": "Gamma", "SUB_DIVISION_SHORT_DESCR": None, "BUSINESS_SEGMENT": "Wholesale"},
]


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_upload_returns_columns_and_message_id():
    payload = {
        "topicId": "multiple_product",
        "chatId": "chat_001",
        "attachments": [_make_csv_b64(SAMPLE_ROWS)],
    }
    resp = client.post("/api/chat/upload", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert "column_names" in body
    assert "message_id" in body
    assert set(body["column_names"]) == {"DIVISION_SHORT_DESCR", "SUB_DIVISION_SHORT_DESCR", "BUSINESS_SEGMENT"}


def test_upload_no_attachments_returns_400():
    payload = {"topicId": "t", "chatId": "c", "attachments": []}
    resp = client.post("/api/chat/upload", json=payload)
    assert resp.status_code == 400


def test_preview_returns_data():
    # First upload so we have a valid message_id
    payload = {"topicId": "t", "chatId": "c", "attachments": [_make_csv_b64(SAMPLE_ROWS)]}
    upload_resp = client.post("/api/chat/upload", json=payload)
    message_id = upload_resp.json()["message_id"]

    resp = client.get(f"/api/preview/{message_id}")
    assert resp.status_code == 200
    assert "data" in resp.json()
    assert len(resp.json()["data"]) == len(SAMPLE_ROWS)


def test_preview_unknown_id_returns_404():
    resp = client.get("/api/preview/nonexistent_id")
    assert resp.status_code == 404


def test_fill_data_removes_nulls():
    payload = {"topicId": "t", "chatId": "c", "attachments": [_make_csv_b64(SAMPLE_ROWS)]}
    upload_resp = client.post("/api/chat/upload", json=payload)
    message_id = upload_resp.json()["message_id"]

    fill_payload = {"message_id": message_id, "messsage": "Fill all the missing data"}
    resp = client.post(f"/api/fill_data/{message_id}", json=fill_payload)
    assert resp.status_code == 200
    data = resp.json()["data"]
    # After ffill/bfill, no cell should be None
    for row in data:
        for val in row.values():
            assert val is not None, f"Null found after fill: {row}"


def test_export_returns_base64_xlsx():
    payload = {"topicId": "t", "chatId": "c", "attachments": [_make_csv_b64(SAMPLE_ROWS)]}
    upload_resp = client.post("/api/chat/upload", json=payload)
    message_id = upload_resp.json()["message_id"]

    export_payload = {"message_id": message_id, "export_format": "xlsx"}
    resp = client.post(f"/api/export/{message_id}", json=export_payload)
    assert resp.status_code == 200
    b64 = resp.json()["data"]
    # Decode and verify it's a valid Excel file
    raw = base64.b64decode(b64)
    df_check = pd.read_excel(io.BytesIO(raw))
    assert list(df_check.columns) == ["DIVISION_SHORT_DESCR", "SUB_DIVISION_SHORT_DESCR", "BUSINESS_SEGMENT"]


def test_export_unsupported_format_returns_400():
    payload = {"topicId": "t", "chatId": "c", "attachments": [_make_csv_b64(SAMPLE_ROWS)]}
    upload_resp = client.post("/api/chat/upload", json=payload)
    message_id = upload_resp.json()["message_id"]

    export_payload = {"message_id": message_id, "export_format": "pdf"}
    resp = client.post(f"/api/export/{message_id}", json=export_payload)
    assert resp.status_code == 400
