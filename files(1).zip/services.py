"""
services.py – Business logic layer for the QUAI API.

Each function corresponds to one API operation and is intentionally
separated from the HTTP layer so it can be unit-tested independently.
"""

import base64
import io
import uuid
from typing import List

import pandas as pd

import store


# ── Upload ─────────────────────────────────────────────────────────────────────

def process_upload(topic_id: str, chat_id: str, attachments: List[str]):
    """
    Decode the first base-64 attachment, parse it as CSV/Excel, store
    the resulting DataFrame, and return the column names + a new message_id.
    """
    if not attachments:
        raise ValueError("At least one attachment is required.")

    raw_bytes = base64.b64decode(attachments[0])
    buf = io.BytesIO(raw_bytes)

    # Attempt CSV first; fall back to Excel
    try:
        df = pd.read_csv(buf)
    except Exception:
        buf.seek(0)
        df = pd.read_excel(buf)

    message_id = uuid.uuid4().hex
    store.save(message_id, df)

    return list(df.columns), message_id


# ── Preview ────────────────────────────────────────────────────────────────────

def get_preview(message_id: str):
    """
    Return the stored DataFrame as a list of dicts (JSON-serialisable).
    Raises KeyError if message_id is unknown.
    """
    df = store.load(message_id)
    if df is None:
        raise KeyError(f"message_id '{message_id}' not found.")

    return df.to_dict(orient="records")


# ── Fill missing data ──────────────────────────────────────────────────────────

def fill_missing_data(message_id: str, instruction: str):
    """
    Apply a simple missing-data strategy, then persist the updated DataFrame.

    For a real product, parse *instruction* and call an LLM or a custom
    imputation pipeline.  Here we use forward-fill + backward-fill as a
    stand-in and add a record that the instruction was acknowledged.
    """
    df = store.load(message_id)
    if df is None:
        raise KeyError(f"message_id '{message_id}' not found.")

    # --- placeholder logic: ffill then bfill ---
    df = df.ffill().bfill()

    # Persist updated frame
    store.save(message_id, df)

    return df.to_dict(orient="records")


# ── Export ─────────────────────────────────────────────────────────────────────

def export_data(message_id: str, export_format: str) -> str:
    """
    Serialise the stored DataFrame to the requested format and return
    the result as a base-64 string.

    Supported formats: xlsx (default), csv.
    """
    df = store.load(message_id)
    if df is None:
        raise KeyError(f"message_id '{message_id}' not found.")

    buf = io.BytesIO()

    fmt = export_format.lower()
    if fmt == "xlsx":
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
    elif fmt == "csv":
        buf.write(df.to_csv(index=False).encode())
    else:
        raise ValueError(f"Unsupported export format: '{export_format}'. Use 'xlsx' or 'csv'.")

    buf.seek(0)
    return base64.b64encode(buf.read()).decode()
