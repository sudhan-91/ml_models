"""
schemas.py – Pydantic request & response models for the QUAI API.
Follows camelCase for JSON properties (as specified in the API design doc).
"""

from typing import Any, List, Optional
from pydantic import BaseModel, Field


# ── /api/chat/upload ──────────────────────────────────────────────────────────

class UploadRequest(BaseModel):
    """Body sent to POST /api/chat/upload."""
    topicId: str = Field(..., example="multiple_product")
    chatId: str = Field(..., example="chat_001")
    attachments: List[str] = Field(
        ...,
        description="List of base-64 encoded file strings.",
        example=["base64_encoded_attachment_string"],
    )


class UploadResponse(BaseModel):
    """Returned by POST /api/chat/upload after parsing the file header row."""
    columnNames: List[str] = Field(
        ...,
        alias="column_names",
        example=["DIVISION_SHORT_DESCR", "SUB_DIVISION_SHORT_DESCR", "BUSINESS_SEGMENT"],
    )
    messageId: str = Field(..., alias="message_id", example="548fdas7asdas545")

    class Config:
        populate_by_name = True


# ── /api/preview/{message_id} ─────────────────────────────────────────────────

class PreviewResponse(BaseModel):
    """Returned by GET /api/preview/{message_id}."""
    data: Any = Field(..., description="DataFrame serialised as a JSON array of objects.")


# ── /api/fill_data/{message_id} ───────────────────────────────────────────────

class FillDataRequest(BaseModel):
    """Body sent to POST /api/fill_data/{message_id}."""
    messageId: str = Field(..., alias="message_id", example="589459as4dasd145")
    message: str = Field(
        ...,
        alias="messsage",          # note: typo preserved from the spec
        example="Fill all the missing data",
    )

    class Config:
        populate_by_name = True


class FillDataResponse(BaseModel):
    """Returned by POST /api/fill_data/{message_id}."""
    data: Any = Field(..., description="DataFrame with missing values filled, serialised as JSON.")


# ── /api/export/{message_id} ──────────────────────────────────────────────────

class ExportRequest(BaseModel):
    """Body sent to POST /api/export/{message_id}."""
    messageId: str = Field(..., alias="message_id", example="589459as4dasd145")
    exportFormat: str = Field(..., alias="export_format", example="xlsx")

    class Config:
        populate_by_name = True


class ExportResponse(BaseModel):
    """Returned by POST /api/export/{message_id}."""
    data: str = Field(..., description="Excel file encoded as base-64 string.")
