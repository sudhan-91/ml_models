import requests
import json


# Prepare the payload with the pipeline serialized as a string
# payload = {
#        "model_name" : "llama3.1"
#     }


payload = {
       "model_name" : "llama3.2-vision"
    }
# Send POST request
# response = requests.post("http://0.0.0.0:8100/models/load_model", json=payload)
response = requests.post("http://0.0.0.0:8101/models/load_model", json=payload)
# Path to your output text file
print(response.json())