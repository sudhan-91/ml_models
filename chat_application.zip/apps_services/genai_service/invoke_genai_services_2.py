import sys
import json
import asyncio
import websockets
import uvicorn
from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.llms import Ollama
output_parser = StrOutputParser()
from fastapi import FastAPI, BackgroundTasks
# Define a Pydantic model for request/response data
class loadModel(BaseModel):
    model_name: str




# Create a FastAPI class-based structure
class MyApp:
    def __init__(self):
        # Initialize the FastAPI app
        self.app = FastAPI()
        # Register routes
        self._register_routes()



    def _register_routes(self):
        """Method to register the routes"""
        self.app.add_api_route("/models/load_model", self.load_model, methods=["POST"])

    async def load_specified_model(self, payload):
        if payload.model_name == "llama3.1":
            self.model = Ollama(model=payload.model_name)
        elif payload.model_name == "llama3.3":
            self.model = Ollama(model=payload.model_name)
        elif payload.model_name == "llama3.2-vision":
            self.model = Ollama(model=payload.model_name)
        server = await websockets.serve(self.streaming_response, "0.0.0.0", 8777)
        print("Server started on ws://0.0.0.0:8777")
        await server.wait_closed()


    async def load_model(self, payload: loadModel, background_tasks: BackgroundTasks):
        response = {"Model Loaded Successfully"}
        try:
            background_tasks.add_task(self.load_specified_model, payload)
            # llm = Ollama(model="llama3.1")

        except Exception as exep:
            print(exep)
            response = {"Model Loading Failed"}
        return response


    async def streaming_response(self, websocket):
        """Api Call to fetch the Database information"""
        response = {}
        try:
            prompt = ChatPromptTemplate.from_messages(
                [
                    # ("system", "You are Purchase Order Processing engine. Please respond to the user queries."),
                    ("system", "Your name is Emmi. Personal Assistant for Emphas-ai"),
                    ("user", "Question: {question}")
                ]
            )
            chain = prompt | self.model | output_parser

            while True:
                # Wait for a request from the client
                request = await websocket.recv()
                print(f"Received request: {request}")
                response = ""
                for chunk in chain.stream({"question": request}):
                    await websocket.send(f"{chunk}")
                    await asyncio.sleep(0.0001)

        except Exception:
            error = f'Error in track_search_options {sys.exc_info()}'
            print(error)
        return response




# Create an instance of the class to run the FastAPI application
my_app = MyApp()

# The FastAPI app instance
app = my_app.app
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],)

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8101)