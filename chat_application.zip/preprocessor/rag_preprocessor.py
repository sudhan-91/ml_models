from langchain_community.document_loaders.csv_loader import CSVLoader
from langchain_community.document_loaders import Docx2txtLoader
from langchain_community.document_loaders import TextLoader
from langchain_community.document_loaders import DirectoryLoader
from langchain_community.document_loaders import UnstructuredHTMLLoader
from langchain_community.document_loaders import JSONLoader
from langchain_community.document_loaders import UnstructuredMarkdownLoader
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.document_loaders import WebBaseLoader


from langchain_text_splitters import HTMLHeaderTextSplitter, HTMLSectionSplitter
from langchain_text_splitters import CharacterTextSplitter, RecursiveCharacterTextSplitter
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai.embeddings import OpenAIEmbeddings
from langchain_text_splitters import (
    Language,
    RecursiveCharacterTextSplitter,
)
from langchain_text_splitters import MarkdownHeaderTextSplitter
from langchain_text_splitters import RecursiveJsonSplitter
from langchain_text_splitters import TokenTextSplitter

from langchain_ollama import OllamaEmbeddings
import bs4
from pathlib import Path


class RagPreprocessor(object):



    def document_loader(self, file_path):
        loader = ""
        try:
            extension = Path(file_path).suffix
            if extension == ".txt":
                loader = TextLoader(file_path)
            elif extension == ".csv":
                loader = CSVLoader(file_path=file_path)
            elif extension == ".pdf":
                loader = PyPDFLoader(file_path)
            elif extension == ".docx":
                loader = Docx2txtLoader(file_path)
            elif extension == ".html":
                loader = UnstructuredHTMLLoader(file_path)
            elif extension == ".json":
                loader = JSONLoader(file_path=file_path)
            elif extension == "url":
                loader = WebBaseLoader(web_paths=(file_path),
                                   bs_kwargs=dict(parse_only=bs4.SoupStrainer(
                                    class_=("post-title", "post-content", "post-header"))))
        except Exception as exep:
            print(exep)
        return loader

    def text_splitter(self, splitter, data):
        try:
            if splitter == "html_header_splitter":
                headers_to_split_on = [("h1", "Header 1"),("h2", "Header 2"),("h3", "Header 3")]
                html_splitter = HTMLHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
                splitted_data = html_splitter.split_text(data)
            elif splitter == "html_section_splitter":
                headers_to_split_on = [("h1", "Header 1"), ("h2", "Header 2")]
                html_splitter = HTMLSectionSplitter(headers_to_split_on=headers_to_split_on)
                splitted_data = html_splitter.split_text(data)
            elif splitter == "character_text_spliiter":
                text_splitter = CharacterTextSplitter(separator="\n\n", chunk_size=1000, chunk_overlap=200, length_function=len, is_separator_regex=False,)
                splitted_data = text_splitter.create_documents([data])
            elif splitter == "character_text_spliiter":
                text_splitter = CharacterTextSplitter(separator="\n\n", chunk_size=1000, chunk_overlap=200, length_function=len, is_separator_regex=False,)
                splitted_data = text_splitter.create_documents([data])
            elif splitter == "custom_logic":
                pass
            elif splitter == "mark_down":
                headers_to_split_on = [("#", "Header 1"),("##", "Header 2"),("###", "Header 3"),]
                markdown_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
                splitted_data = markdown_splitter.split_text(data)
            elif splitter == "json":
                json_splitter = RecursiveJsonSplitter(max_chunk_size=300)
                splitted_data = splitter.create_documents(texts=[data])
                # convert into docs or text as need
                # texts = splitter.split_text(texts=[data])
                # splitted_data = splitter.split_json(json_data=data)
            elif splitter == "recursive_character_text_spliiter":
                text_splitter = RecursiveCharacterTextSplitter(chunk_size=100,chunk_overlap=20,length_function=len,is_separator_regex=False,)
                splitted_data = text_splitter.create_documents([data])
            elif splitter == "semantic_chunking":
                text_splitter = SemanticChunker(OpenAIEmbeddings())
                splitted_data = text_splitter.create_documents([data])
            elif splitter == "recursive_character_tik_tok":
                splitted_data = RecursiveCharacterTextSplitter.from_tiktoken_encoder(model_name="gpt-4",chunk_size=100, chunk_overlap=0,)
            else:
                raise ValueError("Provide the valid Splitter")

        except Exception as exep:
            print(exep)
        return splitted_data

    def vector_embedding(self, embedding_technique, splitted_text):
        try:
            if embedding_technique == "ollama":
                embeddings = OllamaEmbeddings(
                    model="llama3",
                )
                embedded_data = embeddings.embed_documents(splitted_text)
            elif embedding_technique == "openai":
                embeddings_model = OpenAIEmbeddings()
                embedded_data = embeddings_model.embed_documents(splitted_text)

            else:
                raise ValueError("Provide the valid Splitter")
        except Exception as exep:
            print(exep)
        return embedded_data
    def trigger_rag_preprocessor(self, file_path):
        # Specify the splitter from the config
        splitter = ""
        embedding_technique = ""
        try:
            loader = self.document_loader(file_path)
            splitted_text = self.text_splitter(splitter, loader)
            embedded_data  = self.vector_embedding(embedding_technique, splitted_text)



        except Exception as exep:
            print(exep)